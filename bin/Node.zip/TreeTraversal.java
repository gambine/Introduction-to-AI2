import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class TreeTraversal
{

	private Node root;
	public TreeTraversal(Node start)
	{
		root = start;
	}
	public Node root()
	{
		return root;
	}
	 
		
}
